"""
cli.py — quick command-line access without writing a script.

Usage:
    python -m save_editor.cli info save.dat
    python -m save_editor.cli get save.dat player.gold
    python -m save_editor.cli set save.dat player.gold 99999 --out save_edited.dat
    python -m save_editor.cli find save.dat gold
    python -m save_editor.cli diff save1.dat save2.dat
    python -m save_editor.cli dump save.dat            # pretty-print whole tree as JSON
"""

from __future__ import annotations
import sys
import json
import argparse

from .core import SaveFile


def _guess_value_type(raw: str):
    """CLI values arrive as strings; try int, then float, then bool, then leave as string."""
    if raw.lower() in ("true", "false"):
        return raw.lower() == "true"
    try:
        return int(raw)
    except ValueError:
        pass
    try:
        return float(raw)
    except ValueError:
        pass
    return raw


def main(argv=None):
    parser = argparse.ArgumentParser(prog="save_editor")
    sub = parser.add_subparsers(dest="command", required=True)

    p_info = sub.add_parser("info", help="Show detected format")
    p_info.add_argument("file")

    p_dump = sub.add_parser("dump", help="Print the whole save as JSON")
    p_dump.add_argument("file")

    p_get = sub.add_parser("get", help="Read a value at a path")
    p_get.add_argument("file")
    p_get.add_argument("path")

    p_set = sub.add_parser("set", help="Write a value at a path")
    p_set.add_argument("file")
    p_set.add_argument("path")
    p_set.add_argument("value")
    p_set.add_argument("--out", help="Output path (defaults to overwriting input)")

    p_find = sub.add_parser("find", help="Search for a key anywhere in the tree")
    p_find.add_argument("file")
    p_find.add_argument("key")

    p_diff = sub.add_parser("diff", help="Compare two save files")
    p_diff.add_argument("file_a")
    p_diff.add_argument("file_b")

    args = parser.parse_args(argv)

    if args.command == "info":
        sf = SaveFile.load(args.file)
        print(f"format: {sf.fmt.name}")
        if "_wrapper" in sf.meta:
            print(f"wrapped in: {sf.meta['_wrapper']} -> inner format: {sf.meta['_inner_fmt'].name}")

    elif args.command == "dump":
        sf = SaveFile.load(args.file)
        print(json.dumps(sf.data, indent=2, default=str, ensure_ascii=False))

    elif args.command == "get":
        sf = SaveFile.load(args.file)
        print(sf.get(args.path))

    elif args.command == "set":
        sf = SaveFile.load(args.file)
        sf.set(args.path, _guess_value_type(args.value))
        sf.save(args.out or args.file)
        print(f"Wrote {args.out or args.file}")

    elif args.command == "find":
        sf = SaveFile.load(args.file)
        for path, value in sf.find(args.key):
            print(f"{path} = {value!r}")

    elif args.command == "diff":
        sf_a = SaveFile.load(args.file_a)
        sf_b = SaveFile.load(args.file_b)
        for path, old, new in sf_a.diff(sf_b):
            print(f"{path}: {old!r} -> {new!r}")


if __name__ == "__main__":
    main(sys.argv[1:])
