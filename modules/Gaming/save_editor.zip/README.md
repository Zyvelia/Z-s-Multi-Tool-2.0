# save_editor

A general-purpose Python toolkit for reading, editing, and writing back game
save files, regardless of the underlying format.

## Reality check first

There is no such thing as a parser that truly understands *every* binary
save format in existence — every game studio invents its own layout, and
some add encryption or anti-tamper checksums on top. What this library does:

- **Auto-detects and fully round-trips** the formats that cover the large
  majority of saves in practice: JSON, XML, YAML, INI, and any of those
  wrapped in gzip, zlib, or base64.
- **Gives you a fast path for custom binary layouts.** Once you've figured
  out the byte offsets for a specific game (with a hex editor, or with the
  built-in `diff()` helper — see below), you describe them once as a
  `BinaryTemplate` and get named field access forever after, plus automatic
  checksum recalculation so the game doesn't reject your edited save.
- **Falls back to raw bytes** for anything unrecognized, so nothing ever
  crashes on load — you just don't get structured access until you define
  a template for it.

## Install

No dependencies beyond the standard library, except YAML support which is
optional:

```bash
pip install pyyaml   # only needed if you want YAML save support
```

Then drop the `save_editor/` folder into your project (it's not published to
PyPI — copy it in).

## Quick start — structured formats (JSON/XML/YAML/INI, compressed or not)

```python
from save_editor import SaveFile

sf = SaveFile.load("save.json")        # format is auto-detected
print(sf.fmt.name)                     # "json", "gzip", "xml", etc.

print(sf.get("player.gold"))           # dotted-path access
sf.set("player.gold", 999999)
sf.set("inventory.items[2].name", "Excalibur")

sf.save("save_edited.json")            # written back in the original format
```

Compressed saves (very common — Unity/gzip, many mobile games/base64) are
transparent: `SaveFile.load` peels the wrapper, you edit the decoded data,
and `.save()` re-wraps it automatically.

```python
sf = SaveFile.load("save.dat")   # actually gzip-compressed JSON inside
sf.set("player.hp", 100)
sf.save("save.dat")              # re-gzipped automatically
```

### Don't know the exact path?

```python
sf.find("gold")     # -> [("player.gold", 100), ("shop.prices.gold", 5)]
```

### Diffing two saves — the fastest way to find an unknown field

Save the game, change one stat in-game (say, gold), save again, then:

```python
a = SaveFile.load("before.dat")
b = SaveFile.load("after.dat")
print(a.diff(b))   # -> [("player.gold", 100, 150)]
```

This works for structured formats. For raw binary saves, diff the two files
byte-by-byte instead (any hex editor's compare feature, or `diff <(xxd a) <(xxd b)`)
to find the offset — then describe it in a `BinaryTemplate` (below).

## Custom binary saves

```python
from save_editor import BinaryTemplate, Field, ChecksumRule

template = BinaryTemplate(
    fields=[
        Field("gold",   offset=0x10, type="uint32"),
        Field("level",  offset=0x14, type="uint8"),
        Field("name",   offset=0x20, type="cstr", size=16),
        Field("hp",     offset=0x40, type="float32"),
    ],
    # optional: many games store a checksum over the save data and refuse
    # to load if it doesn't match after editing.
    checksum=ChecksumRule("crc32", data_range=(0, 0x100), write_offset=0x100),
)

view = template.load("save.bin")
print(view["gold"], view["name"])
view["gold"] = 999999
view.save("save_edited.bin")   # checksum recalculated automatically
```

Supported field types: `int8/16/32/64`, `uint8/16/32/64`, `float32/64`,
`cstr` (null-terminated string, fixed byte size), `bytes` (raw fixed-size
blob). Checksum algorithms: `crc32`, `adler32`, `sum8/16/32`.

## Command line

```bash
python -m save_editor.cli info save.dat
python -m save_editor.cli get save.dat player.gold
python -m save_editor.cli set save.dat player.gold 99999 --out save_edited.dat
python -m save_editor.cli find save.dat gold
python -m save_editor.cli diff before.dat after.dat
python -m save_editor.cli dump save.dat
```

## Adding a format the library doesn't know

Implement `BaseFormat` (`detect`, `decode`, `encode`) and register it:

```python
from save_editor import register_format
from save_editor.formats import BaseFormat

class MyGameFormat(BaseFormat):
    name = "mygame"
    def detect(self, raw: bytes) -> bool:
        return raw[:4] == b"MYSV"
    def decode(self, raw: bytes):
        ...
        return self, data, {}
    def encode(self, data, meta) -> bytes:
        ...
        return raw

register_format(MyGameFormat(), priority=True)  # checked before built-ins
```

## Layout

```
save_editor/
  __init__.py          public API
  core.py              SaveFile: path get/set/find/diff over any decoded tree
  formats.py           JSON/XML/YAML/INI + gzip/zlib/base64 wrappers, auto-detect
  binary_template.py   BinaryTemplate/Field/ChecksumRule for custom binary layouts
  cli.py                command-line access
```

## A note on legality/etiquette

Editing your own single-player save files is generally fine and extremely
common (that's what this tool is for). Be mindful of:
- Multiplayer/online games with server-authoritative saves or anti-cheat —
  editing local files usually does nothing there, and modifying network
  traffic instead is a different (and often ToS-violating) matter.
- Any save format that's actually encrypted, not just compressed — this
  library doesn't attempt decryption, since that's game-specific and often
  intentionally locked down.
